// cypress/pom/login/POM.cy.js

export default class LoginPage {
    static visit() {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
    }

    static isLoginPageVisible() {
        return cy.get('h5').should('be.visible').and('have.text', 'Login');
    }

    static inputUsername(username) {
        console.log(`Entering username: ${username}`);
        return cy.get('[name="username"]').clear().type(username); 
    }

    static inputPassword(password) {
        return cy.get('[name="password"]').clear().type(password); 
    }

    static buttonSubmit() {
        return cy.get('[type="submit"]').should('be.enabled').click();
    }

    static clickForgotPassword() {
        this.isLoginPageVisible(); 
        return cy.contains('Forgot your password?').click();
    }

    static invalidCredentials() {
        return cy.get('.oxd-alert-content--error').should('be.visible').and('contain.text', 'Invalid credentials');
    }

    static isDashboardVisible() {
        return cy.get('h6').contains('Dashboard').should('be.visible');
    }

    static submitForgotPassword() {
        return cy.get('[type="submit"]').should('be.enabled').click().then(() => {
        });
    }
}
